ra-offline data folder
======================

This folder holds the cache and queue for the ra-offline sysmodule.
It is created by tools/fetch-cache.py (run on your computer, online):

  python3 tools/fetch-cache.py --user YOUR_RA_NAME --password YOUR_RA_PASSWORD \
      --game <gameid> --hash <md5>:<gameid>

Copy the result of that script here:
  account.json              your offline RetroAchievements identity
  cache/hashes.txt          ROM hash -> game id mapping
  cache/<gameid>/patch.json cached achievement data

queue.json (created by the sysmodule) holds unlocks made offline until
they are synced to retroachievements.org.
